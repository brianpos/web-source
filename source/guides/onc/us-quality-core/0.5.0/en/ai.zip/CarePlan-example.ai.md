# CarePlan example - 2026 US Quality Core Implementation Guide v0.5.0

## Example CarePlan: CarePlan example

Assessment and care plan for routine antenatal care during pregnancy.



## Resource Content

```json
{
  "resourceType" : "CarePlan",
  "id" : "example",
  "meta" : {
    "profile" : ["http://fhir.org/guides/onc/us-quality-core/StructureDefinition/us-quality-core-careplan"]
  },
  "status" : "active",
  "intent" : "plan",
  "category" : [{
    "coding" : [{
      "system" : "http://hl7.org/fhir/us/core/CodeSystem/careplan-category",
      "code" : "assess-plan",
      "display" : "Assessment and Plan of Treatment"
    }]
  }],
  "subject" : {
    "display" : "Eve Everywoman"
  },
  "period" : {
    "start" : "2019-05-24",
    "end" : "2020-02-24"
  },
  "careTeam" : [{
    "reference" : "CareTeam/example"
  }],
  "addresses" : [{
    "display" : "pregnancy"
  }],
  "goal" : [{
    "display" : "pregnancy goal"
  }],
  "activity" : [{
    "outcomeReference" : [{
      "display" : "First contact, occurred at about 12 weeks based on gestational age from LMP of 2019-03-01"
    }],
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "in-progress",
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "First antenatal care contact"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "scheduled",
      "scheduledPeriod" : {
        "start" : "2019-07-26"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Second contact to occur at 20 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-09-06"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Third contact to occur at 26 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-10-04"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Fourth contact to occur at 30 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-11-01"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Fifth contact to occur at 34 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-11-15"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Sixth contact to occur at 36 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-11-29"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Seventh contact to occur at 38 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "424525001",
          "display" : "Antenatal care (regime/therapy)"
        }],
        "text" : "Antenatal care"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-12-13"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Eighth contact to occur at 40 weeks of gestational age"
    }
  },
  {
    "detail" : {
      "kind" : "ServiceRequest",
      "code" : {
        "coding" : [{
          "system" : "http://snomed.info/sct",
          "code" : "236973005",
          "display" : "Delivery procedure (procedure)"
        }],
        "text" : "Delivery procedure"
      },
      "status" : "not-started",
      "scheduledPeriod" : {
        "start" : "2019-12-13",
        "end" : "2019-12-27"
      },
      "performer" : [{
        "display" : "Mabel Midwife"
      }],
      "description" : "Delivery"
    }
  }]
}

```
