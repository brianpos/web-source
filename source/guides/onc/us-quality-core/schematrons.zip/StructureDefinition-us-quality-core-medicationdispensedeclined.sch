<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile USCoreMedicationDispenseProfile
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:MedicationDispense</sch:title>
    <sch:rule context="f:MedicationDispense">
      <sch:assert test="count(f:extension[@url = 'http://fhir.org/guides/onc/us-quality-core/StructureDefinition/us-quality-core-recorded']) &gt;= 1">extension with URL = 'http://fhir.org/guides/onc/us-quality-core/StructureDefinition/us-quality-core-recorded': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'http://fhir.org/guides/onc/us-quality-core/StructureDefinition/us-quality-core-recorded']) &lt;= 1">extension with URL = 'http://fhir.org/guides/onc/us-quality-core/StructureDefinition/us-quality-core-recorded': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:statusReason[x]) &gt;= 1">statusReason[x]: minimum cardinality of 'statusReason[x]' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
  <sch:pattern>
    <sch:title>f:MedicationDispense/f:dosageInstruction/f:doseAndRate</sch:title>
    <sch:rule context="f:MedicationDispense/f:dosageInstruction/f:doseAndRate">
      <sch:assert test="count(f:type) &gt;= 1">type: minimum cardinality of 'type' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
